import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import searchCertificationRequest from "@salesforce/apex/CertificationRequest.searchCertificationRequest";
export default class CertificationRequestSearch extends NavigationMixin(LightningElement) {
    @api recordId;
    @track searchTerm = '';

    @track certificationRequests;
    @wire(CurrentPageReference) pageRef;
    @wire(searchCertificationRequest, { searchTerm: '$searchTerm' })
    loadBears(result) {
        this.certificationRequests = result;
        if (result.data) {
            fireEvent(this.pageRef, 'certificationRequestListUpdate', result.data);
        }
    }

    handleSearchTermChange(event) {


        // long as this function is being called within a delay of 300 ms.
        // This is to avoid a very large number of Apex method calls.

        window.clearTimeout(this.delayTimeout);
        const searchTerm = event.target.value;

        // eslint-disable-next-line @lwc/lwc/no-async-operation      
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300);
    }

    get hasResults() {
        return (this.certificationRequests.data.length > 0);
    }

    handleEmpView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification_Request__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
    
}