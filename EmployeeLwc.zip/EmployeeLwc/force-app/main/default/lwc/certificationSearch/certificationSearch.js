import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import searchCertifications from "@salesforce/apex/Certification.searchCertifications";
export default class CertificationSearch extends NavigationMixin(LightningElement) {
    @api recordId;
    @track searchTerm = '';

    @track certifications;
    @wire(CurrentPageReference) pageRef;
    @wire(searchCertifications, { searchTerm: '$searchTerm' })
    loadBears(result) {
        this.certifications = result;
        if (result.data) {
            fireEvent(this.pageRef, 'certificationListUpdate', result.data);
        }
    }

    handleSearchTermChange(event) {


        // long as this function is being called within a delay of 300 ms.
        // This is to avoid a very large number of Apex method calls.

        window.clearTimeout(this.delayTimeout);
        const searchTerm = event.target.value;

        // eslint-disable-next-line @lwc/lwc/no-async-operation      
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300);
    }

    get hasResults() {
        return (this.certifications.data.length > 0);
    }

    handleEmpView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Certification__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
    
}