import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class EditOverride extends NavigationMixin(LightningElement) {
    @api recordId;
    handleSubmit(event) {
        console.log('onsubmit: '+ event.detail.fields);
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
        });
        
 
    }
    handleSuccess(event) {
        const updatedRecord = event.detail.id;
        console.log('onsuccess: ', updatedRecord);
        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Employee record is updated',
            variant: 'success',
        });
        this.dispatchEvent(evt);

        eval("$A.get('e.force:refreshView').fire();");
    }

    cancelNavigate() 
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
}