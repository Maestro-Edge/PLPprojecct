import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import searchEmployees from "@salesforce/apex/Employees.searchEmployees";
export default class SearchEmp extends NavigationMixin(LightningElement) {
	@api recordId;
    @track searchTerm = '';

    @track employees;
    @wire(CurrentPageReference) pageRef;
    @wire(searchEmployees, { searchTerm: '$searchTerm' })
    loadBears(result) {
        this.employees = result;
        if (result.data) {
            fireEvent(this.pageRef, 'employeeListUpdate', result.data);
        }
    }

    handleSearchTermChange(event) {


        // long as this function is being called within a delay of 300 ms.
        // This is to avoid a very large number of Apex method calls.

        window.clearTimeout(this.delayTimeout);
        const searchTerm = event.target.value;

        // eslint-disable-next-line @lwc/lwc/no-async-operation      
        this.delayTimeout = setTimeout(() => {
            this.searchTerm = searchTerm;
        }, 300);
    }

    get hasResults() {
        return (this.employees.data.length > 0);
    }

	handleEmpView(event)
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.target.value,
                objectApiName: 'Employee__c',
                actionName: 'view',
            },
        });
        eval("$A.get('e.force:refreshView').fire();");
	}
	
}