import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class VoucherEdit  extends NavigationMixin(LightningElement) {
    @api recordId;
    handleSubmit(event) {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
        });
        //eval("$A.get('e.force:refreshView').fire();");
        
    }
    handleSuccess(event) {
        const updatedRecord = event.detail.id;
        console.log('onsuccess: ', updatedRecord);
        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Voucher record is updated',
            variant: 'success',
        });
        this.dispatchEvent(evt);
    }

    cancelNavigate() 
    {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.recordId,
                actionName: 'view'
            }
        });
        eval("$A.get('e.force:refreshView').fire();");
    }
}