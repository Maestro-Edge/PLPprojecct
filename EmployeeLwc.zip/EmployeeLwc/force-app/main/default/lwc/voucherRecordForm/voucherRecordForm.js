import { LightningElement, api } from 'lwc';

export default class VoucherRecordForm extends LightningElement {
    @api recordId;
    @api objectApiName;
}